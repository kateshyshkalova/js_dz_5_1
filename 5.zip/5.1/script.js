let season = +prompt('Введіть число');
switch (season) {
    case (1):
        document.write('Зима');
        break;
    case (2):
        document.write('Зима');
        break;
    case (12):
        document.write('Зима');
        break;
    case (3):
        document.write('Весна');
        break;
    case (4):
        document.write('Весна');
        break;
    case (5):
        document.write('Весна');
        break;
    case (6):
        document.write('Літо');
        break;
    case (7):
        document.write('Літо');
        break;
    case (8):
        document.write('Літо');
        break;
    case (9):
        document.write('Осінь');
        break;
    case (10):
        document.write('Осінь');
        break;
    case (11):
        document.write('Осінь');
        break;
    default:
        document.write('Визначити пору року не можливо. Введіть число від 1 до 12');
        break;
}